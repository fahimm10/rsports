package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class BillingAddress {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO) //Automatically generate value for Id using sequence

	private int id;
	@NotEmpty(message="appartmentnumber is name is mandatory")
	private String appartmentnumber;
	@NotEmpty(message="City is name is mandatory")
	private String city;
	@NotEmpty(message="State is name is mandatory")
	private String state;
	@NotEmpty(message="Zipcode is name is mandatory")
	private String zipcode;
	@NotEmpty(message="streetname is name is mandatory")
	private String streetname;
	public String getAppartmentnumber() {
		return appartmentnumber;
	}
	public void setAppartmentnumber(String appartmentnumber) {
		this.appartmentnumber = appartmentnumber;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStreetname() {
		return streetname;
	}
	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
}
