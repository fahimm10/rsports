package com.niit.dao;

import com.niit.model.Cart;
import com.niit.model.CartItem;
import com.niit.model.CustomerOrder;

public interface CartItemDao {
public void saveOrUpdateCartItem(CartItem cartItem);
public void removeCartItem(int cartItemId);
public Cart getCart(int cartId);
public CustomerOrder createOrder(Cart cart);
}
